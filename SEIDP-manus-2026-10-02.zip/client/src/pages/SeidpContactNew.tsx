import { ArrowDown, ArrowUpRight, Clock3, MapPin, Phone } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { APPOINTMENT_PHONE, Eyebrow, PageIntro, PageShell, URGENCY_PHONE, WHATSAPP_URL, WhatsAppIcon } from "@/components/SeidpLayout";

const questions = [
  ["¿Cómo puedo agendar?", "Escríbenos por WhatsApp o llama al 322 403 5071. Te ayudaremos a confirmar el estudio y la disponibilidad."],
  ["¿Qué debo llevar el día de mi estudio?", "Lleva tu orden médica si cuentas con una, una identificación y estudios previos relacionados. Al agendar te confirmaremos si necesitas algo adicional."],
  ["¿Cuándo recibiré mis resultados?", "El tiempo de entrega depende del estudio. Pregunta por el plazo estimado al agendar o durante tu atención."],
  ["¿Qué información de salud debo compartir?", "Avísanos si estás embarazada o podrías estarlo, si tienes alergias, implantes, marcapasos o tomas medicamentos relevantes."],
  ["¿Atienden fines de semana?", "Sí. Sábado y domingo atendemos de 8:00 a. m. a 2:00 p. m., sujeto a disponibilidad."],
  ["¿Atienden urgencias?", "Llama al 322 132 7405 para confirmar atención. Este número no sustituye al 911 ni a una ambulancia."],
] as const;

export default function SeidpContactNew() {
  return (
    <PageShell darkHeader>
      <main>
        <section className="relative isolate flex min-h-screen items-end overflow-hidden bg-[#082b46] pb-14 pt-32 text-white sm:pb-20">
          <img src="/media/seidp-contacto-clinica.webp" alt="Entrada de una clínica en Puerto Vallarta" fetchPriority="high" className="absolute inset-0 h-full w-full object-cover object-center" />
          <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(8,43,70,.96),rgba(8,43,70,.72)_52%,rgba(8,43,70,.22))]" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#082b46]/70 via-transparent to-[#082b46]/20" />
          <div className="relative z-10 mx-auto w-full max-w-[1280px] px-5 sm:px-8 lg:px-12">
            <PageIntro eyebrow="Contacto · Puerto Vallarta" title="Hablemos." italic="Estamos cerca." description="Una duda, un estudio, tu próxima cita. Cuéntanos qué necesitas y te ayudamos a dar el siguiente paso." dark />
            <a href="#hablar" className="mt-8 inline-flex items-center gap-3 text-xs font-semibold text-white"><span className="grid size-9 place-items-center rounded-full border border-white/40"><ArrowDown className="size-4" /></span>Habla con nosotros</a>
          </div>
        </section>
        <section id="hablar" className="scroll-mt-24 bg-[#f1f6f8] py-12 sm:py-16">
          <div className="mx-auto w-full max-w-[1280px] px-5 sm:px-8 lg:px-12">
            <div className="grid overflow-hidden rounded-2xl border border-[#12395d]/10 md:grid-cols-3">
              <a href={WHATSAPP_URL} target="_blank" rel="noreferrer" className="group flex flex-col bg-[#0f7065] p-7 text-white transition-colors hover:bg-[#0b6258]">
                <span className="flex items-center justify-between"><WhatsAppIcon className="size-6" /><ArrowUpRight className="size-5" /></span><span className="mt-7 text-[10px] font-bold uppercase tracking-[.16em] text-white/75">Escríbenos por WhatsApp</span><strong className="mt-2 font-display text-2xl font-semibold tracking-[-.04em]">322 470 4622</strong><span className="mt-3 text-sm text-white/80">Consulta estudios, preparación y citas.</span>
              </a>
              <a href={`tel:${APPOINTMENT_PHONE}`} className="flex flex-col border-b border-[#12395d]/10 bg-white p-7 text-[#12395d] transition-colors hover:bg-[#e8f5f5] md:border-b-0 md:border-r">
                <span className="flex items-center justify-between"><Phone className="size-6 text-[#0f7065]" /><ArrowUpRight className="size-5" /></span><span className="mt-7 text-[10px] font-bold uppercase tracking-[.16em] text-[#597286]">Llama para agendar</span><strong className="mt-2 font-display text-2xl font-semibold tracking-[-.04em]">322 403 5071</strong><span className="mt-3 text-sm text-[#597286]">Conversemos sobre tu próxima visita.</span>
              </a>
              <a href={`tel:${URGENCY_PHONE}`} className="flex flex-col bg-white p-7 text-[#12395d] transition-colors hover:bg-[#e8f5f5]">
                <span className="flex items-center justify-between"><Clock3 className="size-6 text-[#0f7065]" /><ArrowUpRight className="size-5" /></span><span className="mt-7 text-[10px] font-bold uppercase tracking-[.16em] text-[#597286]">Atención de urgencias</span><strong className="mt-2 font-display text-2xl font-semibold tracking-[-.04em]">322 132 7405<span className="sr-only">, llamar a urgencias</span></strong><span className="mt-3 text-xs leading-relaxed text-[#597286]">Llama para confirmar atención. No sustituye al 911 ni a una ambulancia.</span>
              </a>
            </div>
          </div>
        </section>
        <section id="encuentranos" className="scroll-mt-24 bg-[#fbfdfe] py-16 sm:py-24">
          <div className="mx-auto max-w-[1280px] px-5 sm:px-8 lg:px-12">
            <div className="mb-10 flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><Eyebrow>Aquí nos encontramos</Eyebrow><h2 className="font-display text-4xl font-semibold tracking-[-.05em] text-[#12395d] sm:text-5xl">En el corazón de Coapinole.</h2></div><span className="flex shrink-0 items-center gap-2 text-xs text-[#597286]"><MapPin className="size-4 text-[#0f7065]" />Puerto Vallarta, Jalisco</span></div>
            <div className="grid overflow-hidden rounded-[24px] bg-[#082b46] lg:grid-cols-[.85fr_1.5fr]">
              <div className="flex flex-col p-7 text-white sm:p-10">
                <p className="text-[10px] font-bold uppercase tracking-[.16em] text-[#7ab2db]">Nuestra dirección</p><h3 className="mt-4 font-display text-3xl font-semibold tracking-[-.04em]">Calle 10 de Mayo<br />#980</h3><p className="mt-4 text-sm leading-relaxed text-white/70">Entre Guatemala y Brasil.<br />Colonia Coapinole, Puerto Vallarta, Jalisco.</p>
                <dl className="my-8 space-y-4 border-y border-white/15 py-6 text-sm"><div><dt className="text-white/60">Lunes a viernes</dt><dd className="mt-1 font-semibold">8:00 a. m. - 8:00 p. m.</dd></div><div><dt className="text-white/60">Sábado y domingo</dt><dd className="mt-1 font-semibold">8:00 a. m. - 2:00 p. m.</dd></div></dl>
                <a href="https://maps.app.goo.gl/EnPoYMCfZ6Cm4Fzs7" target="_blank" rel="noreferrer" className="mt-auto flex items-center justify-between gap-4 rounded-full bg-white px-6 py-4 text-xs font-bold text-[#12395d] transition-colors hover:bg-[#dceef4]">Abrir ruta en Google Maps<ArrowUpRight className="size-4" /></a>
              </div>
              <iframe title="Ubicación de Salud e Imagen del Puerto" src="https://www.google.com/maps?q=Calle%2010%20de%20Mayo%20980%2C%20Coapinole%2C%20Puerto%20Vallarta%2C%20Jalisco&z=16&output=embed" className="h-full min-h-[360px] w-full border-0 bg-[#dceef4] lg:min-h-[520px]" loading="lazy" referrerPolicy="no-referrer-when-downgrade" />
            </div>
          </div>
        </section>
        <section className="bg-[#e8f5f5] py-16 sm:py-24">
          <div className="mx-auto grid max-w-[1280px] gap-8 px-5 sm:px-8 lg:grid-cols-[.8fr_1.2fr] lg:gap-20 lg:px-12">
            <div><Eyebrow>Antes de tu visita</Eyebrow><h2 className="max-w-sm font-display text-4xl font-semibold leading-[1.05] tracking-[-.05em] text-[#12395d] sm:text-5xl">Menos dudas.<br /><span className="text-[#0f7065] italic">Más tranquilidad.</span></h2><p className="mt-5 max-w-xs text-sm leading-relaxed text-[#597286]">Lo que necesitas saber para llegar con claridad a tu cita.</p></div>
            <Accordion type="single" collapsible className="border-t border-[#12395d]/20">{questions.map(([question, answer], index) => <AccordionItem key={question} value={question} className="border-[#12395d]/20"><AccordionTrigger className="gap-4 py-6 text-left font-display text-base font-semibold tracking-[-.025em] text-[#12395d] hover:no-underline sm:text-lg"><span className="flex items-baseline gap-4"><span className="font-sans text-[10px] text-[#0f7065]">0{index + 1}</span>{question}</span></AccordionTrigger><AccordionContent className="pb-6 pl-7 text-sm leading-relaxed text-[#597286]">{answer}</AccordionContent></AccordionItem>)}</Accordion>
          </div>
        </section>
      </main>
    </PageShell>
  );
}

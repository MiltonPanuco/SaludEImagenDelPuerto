import { Activity, ArrowRight, Check, Heart, MessageCircle, ShieldCheck, Stethoscope } from "lucide-react";
import { Link } from "wouter";
import { AnimatedStat } from "@/components/AnimatedStat";
import { Eyebrow, PageIntro, PageShell, WhatsAppButton } from "@/components/SeidpLayout";

const packages = [
  {
    title: "Check-up para mujer",
    label: "Prevención integral",
    Icon: Heart,
    accentClass: "text-[#d65387]",
    backgroundClass: "bg-[#fcecf3]",
    items: ["BH", "QS 3", "Perfil de lípidos", "EGO", "Ultrasonido pélvico", "Ultrasonido mamario"],
  },
  {
    title: "Check-up para hombre",
    label: "Seguimiento preventivo",
    Icon: ShieldCheck,
    accentClass: "text-[#6b3fa0]",
    backgroundClass: "bg-[#f4effa]",
    items: ["BH", "QS 3", "Perfil de lípidos", "EGO", "Antígeno prostático", "Testosterona opcional", "Ultrasonido prostático"],
  },
] as const;

export default function SeidpPreventionNew() {
  return (
    <PageShell darkHeader>
      <main>
        <section className="relative isolate flex min-h-screen items-end overflow-hidden bg-[#082b46] pb-14 pt-[104px] text-white sm:pb-20">
          <img src="/media/seidp-prevencion-mujer.webp" alt="Consulta médica orientada a la prevención" className="absolute inset-0 h-full w-full object-cover object-center opacity-70" />
          <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(8,43,70,.28),rgba(8,43,70,.72)_48%,rgba(8,43,70,.96))]" />
          <div className="relative mx-auto w-full max-w-[1280px] px-5 sm:px-8 lg:px-12">
            <PageIntro eyebrow="Prevención" title="Conocer tu salud hoy" italic="cambia tus decisiones mañana." description="Opciones de check-up para iniciar una conversación informada con nuestro equipo y elegir estudios de acuerdo con tu etapa de vida." dark right />
          </div>
        </section>

        <section className="bg-[#fbfdfe] py-18 sm:py-24">
          <div className="mx-auto max-w-[1180px] px-5 sm:px-8 lg:px-12">
            <div className="grid gap-10 lg:grid-cols-[.8fr_1.2fr] lg:items-end">
              <div><Eyebrow>Prevenir es observar a tiempo</Eyebrow><h2 className="font-display text-4xl font-semibold leading-[.96] tracking-[-.05em] text-[#12395d] sm:text-5xl">Un punto de partida para cuidar lo que sigue.</h2></div>
              <p className="max-w-xl text-sm leading-relaxed text-[#597286]">Los check-ups no sustituyen una valoración médica. Son una forma práctica de reunir información útil para hablar con un profesional y dar seguimiento a tu bienestar.</p>
            </div>
            <div className="mt-12 grid gap-4 md:grid-cols-3">
              {[[Activity, "Detectar cambios", "Comparar resultados ayuda a identificar variaciones que merecen seguimiento."], [Stethoscope, "Decidir con información", "Tus resultados pueden orientar una conversación más útil con tu médico."], [MessageCircle, "Resolver dudas", "Nuestro equipo confirma contigo preparación, requisitos y disponibilidad."]].map(([Icon, title, text]) => { const ValueIcon = Icon as typeof Activity; return <article key={title as string} className="rounded-[20px] border border-[#12395d]/10 bg-white p-6 sm:p-8"><span className="grid size-11 place-items-center rounded-full bg-[#e8f5f5] text-[#0f7065]"><ValueIcon className="size-5" /></span><h3 className="mt-8 font-display text-2xl font-semibold tracking-[-.04em] text-[#12395d]">{title as string}</h3><p className="mt-3 text-sm leading-relaxed text-[#597286]">{text as string}</p></article>; })}
            </div>
          </div>
        </section>

        <section className="bg-[#12395d] py-14 text-white sm:py-16" aria-label="Opciones preventivas en números">
          <div className="mx-auto grid max-w-[1180px] grid-cols-2 gap-8 px-5 sm:px-8 lg:grid-cols-4 lg:px-12">
            <AnimatedStat value={600} suffix="+" label="Evaluaciones preventivas" />
            <AnimatedStat value={5000} suffix="+" label="Análisis de laboratorio" />
            <AnimatedStat value={2} label="Opciones de check-up" />
            <AnimatedStat value={7} label="Días con atención" />
          </div>
        </section>

        <section className="bg-[#f1f6f8] py-18 sm:py-24">
          <div className="mx-auto max-w-[1180px] px-5 sm:px-8 lg:px-12">
            <div className="max-w-2xl"><Eyebrow>Opciones preventivas</Eyebrow><h2 className="font-display text-4xl font-semibold leading-[.96] tracking-[-.05em] text-[#12395d] sm:text-5xl">Elige una base y confirma qué necesitas.</h2></div>
            <div className="mt-12 grid gap-5 lg:grid-cols-2">
              {packages.map(({ title, label, Icon, accentClass, backgroundClass, items }) => (
                <article key={title} className="overflow-hidden rounded-[22px] bg-white shadow-[0_14px_36px_rgba(18,57,93,.07)]">
                  <div className={`flex items-center justify-between p-6 sm:p-8 ${backgroundClass}`}><span className={`grid size-12 place-items-center rounded-full bg-white ${accentClass}`}><Icon className="size-5" /></span><span className={`text-[9px] font-bold uppercase tracking-[.15em] ${accentClass}`}>{label}</span></div>
                  <div className="p-6 sm:p-8"><h3 className="font-display text-3xl font-semibold tracking-[-.04em] text-[#12395d]">{title}</h3><ul className="mt-7 grid gap-3 sm:grid-cols-2">{items.map(item => <li key={item} className="flex items-center gap-2 text-sm text-[#597286]"><Check className={`size-4 shrink-0 ${accentClass}`} />{item}</li>)}</ul><Link href="/contacto" className={`mt-8 inline-flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.13em] ${accentClass}`}>Consultar disponibilidad <ArrowRight className="size-4" /></Link></div>
                </article>
              ))}
            </div>
            <p className="mt-6 text-xs leading-relaxed text-[#597286]">Los estudios incluidos, precios, vigencia y condiciones deben confirmarse antes de agendar.</p>
          </div>
        </section>

        <section className="bg-white py-18 sm:py-24">
          <div className="mx-auto grid max-w-[1180px] gap-10 px-5 sm:px-8 lg:grid-cols-[1.05fr_.95fr] lg:items-center lg:px-12">
            <div className="overflow-hidden rounded-[24px] bg-[#dceef4]"><img src="/media/seidp-prevention-family.webp" alt="Orientación médica para elegir estudios preventivos" className="aspect-[4/3] h-full w-full object-cover" loading="lazy" decoding="async" /></div>
            <div><Eyebrow>Cómo comenzar</Eyebrow><h2 className="font-display text-4xl font-semibold leading-[.96] tracking-[-.05em] text-[#12395d] sm:text-5xl">Tres pasos, sin complicaciones.</h2><div className="mt-8 border-t border-[#12395d]/12">{[["01", "Cuéntanos qué deseas revisar"], ["02", "Confirma estudios y preparación"], ["03", "Agenda el horario que te funcione"]].map(([number, text]) => <div key={number} className="grid grid-cols-[2.5rem_1fr] gap-4 border-b border-[#12395d]/12 py-5"><span className="text-xs font-bold text-[#0f7065]">{number}</span><p className="font-display text-xl font-semibold text-[#12395d]">{text}</p></div>)}</div><div className="mt-8"><WhatsAppButton>Hablar con el equipo</WhatsAppButton></div></div>
          </div>
        </section>
      </main>
    </PageShell>
  );
}

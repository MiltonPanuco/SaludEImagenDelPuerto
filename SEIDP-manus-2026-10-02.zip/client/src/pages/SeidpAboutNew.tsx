import { ArrowRight, Eye, HeartHandshake, ShieldCheck } from "lucide-react";
import { Link } from "wouter";
import { Eyebrow, PageIntro, PageShell } from "@/components/SeidpLayout";

export default function SeidpAboutNew() {
  return (
    <PageShell darkHeader>
      <main className="flex flex-col">
        <section className="relative isolate flex min-h-screen items-end overflow-hidden bg-[#082b46] pb-6 pt-36 text-white sm:pb-8">
          <img src="/media/seidp-consulta-medica.webp" alt="Profesional de la salud conversando con una paciente" className="absolute inset-0 h-full w-full object-cover object-center opacity-70" />
          <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(8,43,70,.94),rgba(8,43,70,.72)_52%,rgba(8,43,70,.3))]" />
          <div className="relative mx-auto w-full max-w-[1280px] px-5 sm:px-8 lg:px-12">
            <PageIntro eyebrow="Nosotros" title="Diagnóstico cercano," italic="decisiones más claras." description="Un centro de salud creado para acercar imagen, laboratorio, prevención y orientación profesional a Coapinole y Puerto Vallarta." dark />
          </div>
        </section>

        <section className="order-1 bg-[#fbfdfe] pb-10 pt-16 sm:pb-12 sm:pt-24">
          <div className="mx-auto grid max-w-[1180px] gap-10 px-5 sm:px-8 lg:grid-cols-[.9fr_1.1fr] lg:items-center lg:gap-20 lg:px-12">
            <div className="overflow-hidden rounded-[24px] bg-[#dceef4]"><img src="/media/seidp-prevention-family.webp" alt="Atención médica y orientación profesional" className="aspect-[4/5] h-full w-full object-cover" loading="lazy" decoding="async" /></div>
            <div>
              <Eyebrow>Nuestra historia</Eyebrow>
              <h2 className="font-display text-4xl font-semibold leading-[.96] tracking-[-.05em] text-[#12395d] sm:text-5xl">Nacimos para acercar estudios confiables a nuestra comunidad.</h2>
              <div className="mt-7 space-y-4 text-[15px] leading-relaxed text-[#597286]">
                <p>Salud e Imagen del Puerto surge en Coapinole con una idea sencilla: reunir servicios de diagnóstico y prevención en un lugar accesible, con atención humana.</p>
                <p>Desde el inicio buscamos que cada persona comprenda su proceso, reciba indicaciones claras y encuentre acompañamiento antes y después de su estudio.</p>
              </div>
              <div className="mt-9 grid grid-cols-2 gap-4 border-t border-[#12395d]/12 pt-6">
                <div><p className="font-display text-3xl font-semibold text-[#0f7065]">Local</p><p className="mt-1 text-xs text-[#597286]">Cerca de Coapinole</p></div>
                <div><p className="font-display text-3xl font-semibold text-[#0f7065]">Integral</p><p className="mt-1 text-xs text-[#597286]">Imagen, laboratorio y prevención</p></div>
              </div>
            </div>
          </div>
        </section>

        <section className="order-4 bg-[#e8f5f5] py-16 sm:py-24">
          <div className="mx-auto grid max-w-[1180px] gap-12 px-5 sm:px-8 lg:grid-cols-[1.1fr_1fr] lg:gap-20 lg:px-12">
            <div>
              <Eyebrow>El compromiso que nos mueve</Eyebrow>
              <h2 className="max-w-xl font-display text-4xl font-semibold leading-[1.05] tracking-[-.05em] text-[#12395d] sm:text-6xl">De nuestra comunidad.<br /><span className="text-[#0f7065] italic">Para nuestra comunidad.</span></h2>
              <Link href="/contacto" className="mt-8 inline-flex items-center gap-4 border-b border-[#0f7065]/30 pb-3 text-xs font-bold text-[#0f7065]">Estamos cerca de ti <ArrowRight className="size-4" /></Link>
            </div>
            <div className="divide-y divide-[#12395d]/15 border-y border-[#12395d]/15">
              <article className="grid grid-cols-[2rem_1fr] gap-4 py-7"><span className="pt-1 text-xs text-[#0f7065]">01</span><div><p className="text-[10px] font-bold uppercase tracking-[.18em] text-[#0f7065]">Nuestra misión · Hoy</p><h3 className="mt-3 font-display text-2xl font-semibold tracking-[-.04em] text-[#12395d]">Hacer más cercano el cuidado de tu salud.</h3><p className="mt-3 text-sm leading-relaxed text-[#597286]">Facilitar el acceso a estudios y orientación profesional, con calidad, trato humano e indicaciones claras en cada visita.</p></div></article>
              <article className="grid grid-cols-[2rem_1fr] gap-4 py-7"><span className="pt-1 text-xs text-[#0f7065]">02</span><div><p className="text-[10px] font-bold uppercase tracking-[.18em] text-[#0f7065]">Nuestra visión · Mañana</p><h3 className="mt-3 font-display text-2xl font-semibold tracking-[-.04em] text-[#12395d]">Crecer contigo, seguir cerca.</h3><p className="mt-3 text-sm leading-relaxed text-[#597286]">Ser un referente de salud diagnóstica en Puerto Vallarta, con atención profesional y una comunicación siempre comprensible.</p></div></article>
            </div>
          </div>
        </section>

        <section className="order-3 bg-[#082b46] py-18 text-white sm:py-24">
          <div className="mx-auto grid max-w-[1180px] gap-10 px-5 sm:px-8 lg:grid-cols-[1fr_.9fr] lg:items-center lg:px-12">
            <div>
              <Eyebrow light>Las personas detrás del centro</Eyebrow>
              <h2 className="max-w-xl font-display text-4xl font-semibold leading-[.96] tracking-[-.05em] sm:text-5xl">Un equipo que escucha antes de comenzar.</h2>
              <p className="mt-6 max-w-lg text-sm leading-relaxed text-white/60">Nos tomamos el tiempo de escuchar tus dudas, conocer el motivo de tu visita y explicarte los siguientes pasos con claridad.</p>
              <Link href="/contacto" className="mt-8 inline-flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.14em] text-[#7ab2db]">Conoce dónde estamos <ArrowRight className="size-4" /></Link>
            </div>
            <div className="overflow-hidden rounded-[22px] bg-[#12395d]"><img src="/media/seidp-consulta-medica.webp" alt="Profesional de salud escuchando a una paciente" className="aspect-[4/3] h-full w-full object-cover" loading="lazy" decoding="async" /></div>
          </div>
        </section>

        <section className="order-2 bg-white pb-18 pt-8 sm:pb-24 sm:pt-10">
          <div className="mx-auto max-w-[1180px] px-5 sm:px-8 lg:px-12">
            <div className="grid gap-4 sm:grid-cols-3">
              {[[HeartHandshake, "Cercanía", "Tratamos a cada persona con respeto y atención."], [ShieldCheck, "Confianza", "Comunicamos indicaciones con honestidad y claridad."], [Eye, "Prevención", "Impulsamos decisiones informadas antes de que aparezcan síntomas."]].map(([Icon, title, text]) => { const ValueIcon = Icon as typeof Eye; return <article key={title as string} className="rounded-[18px] border border-[#12395d]/10 p-6"><ValueIcon className="size-6 text-[#0f7065]" /><h3 className="mt-8 font-display text-2xl font-semibold text-[#12395d]">{title as string}</h3><p className="mt-3 text-sm leading-relaxed text-[#597286]">{text as string}</p></article>; })}
            </div>
          </div>
        </section>
      </main>
    </PageShell>
  );
}
